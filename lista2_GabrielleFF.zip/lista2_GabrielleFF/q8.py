# Crie uma classe chamada “Aluno” com atributos “nome” e “notas”. Implemente um método chamado “calcular_media” que retorna a média das notas do aluno.

class Aluno:
    def __init__(self, nome, notas):
        self.nome = nome
        self.notas = notas

    def calcular_media(self):
        if len(self.notas) > 0:
            return sum(self.notas) / len(self.notas)
        else:
            return 0.0  # Retorna 0 se não houver notas.

# Exemplo de uso:
notas_aluno1 = [8.5, 9.0, 7.5, 8.0]
aluno1 = Aluno("Alice", notas_aluno1)
media_aluno1 = aluno1.calcular_media()
print(f"Média das notas de {aluno1.nome}: {media_aluno1}")

notas_aluno2 = [7.0, 6.5, 7.5, 8.0]
aluno2 = Aluno("Bob", notas_aluno2)
media_aluno2 = aluno2.calcular_media()
print(f"Média das notas de {aluno2.nome}: {media_aluno2}")
