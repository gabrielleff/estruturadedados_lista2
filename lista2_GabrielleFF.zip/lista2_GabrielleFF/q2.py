# Crie uma classe chamada “Livro” que tenha atributos “titulo” e “autor”. Implemente um método chamado “detalhes” que retorna uma string com as informações do livro.

class Livro:
    def __init__(self, titulo, autor):
        self.titulo = titulo
        self.autor = autor

    def detalhes(self):
        return f"Título: {self.titulo}\nAutor: {self.autor}"

# Exemplo de uso:
livro1 = Livro("Dom Quixote", "Miguel de Cervantes")
detalhes_livro1 = livro1.detalhes()
print(detalhes_livro1)

livro2 = Livro("Orgulho e Preconceito", "Jane Austen")
detalhes_livro2 = livro2.detalhes()
print(detalhes_livro2)
