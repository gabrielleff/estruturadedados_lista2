# Crie uma classe chamada “Retangulo” que tenha atributos “base” e “altura”. Implemente um método chamado “calcular_area” que retorna a área do retângulo.

class Retangulo:
    def __init__(self, base, altura):
        self.base = base
        self.altura = altura

    def calcular_area(self):
        return self.base * self.altura

# Exemplo de uso:
base_do_retangulo = 4
altura_do_retangulo = 6
retangulo = Retangulo(base_do_retangulo, altura_do_retangulo)
area = retangulo.calcular_area()
print(f"A área do retângulo com base {base_do_retangulo} e altura {altura_do_retangulo} é {area}")
