# Crie uma classe chamada “Produto” com atributos “nome”, “preco” e “quantidade”. Implemente um método chamado “calcular_total” que retorna o valor total do produto (preço * quantidade).

class Produto:
    def __init__(self, nome, preco, quantidade):
        self.nome = nome
        self.preco = preco
        self.quantidade = quantidade

    def calcular_total(self):
        return self.preco * self.quantidade

# Exemplo de uso:
produto1 = Produto("Camiseta", 25.0, 3)
total1 = produto1.calcular_total()
print(f"Produto: {produto1.nome}, Preço: R${produto1.preco}, Quantidade: {produto1.quantidade}, Total: R${total1}")

produto2 = Produto("Livro", 15.0, 5)
total2 = produto2.calcular_total()
print(f"Produto: {produto2.nome}, Preço: R${produto2.preco}, Quantidade: {produto2.quantidade}, Total: R${total2}")
