# Crie uma classe chamada “Funcionario” com atributos “nome”, “salario” e “cargo”. Implemente um método chamado “aumentar_salario” que recebe um valor percentual de aumento e atualiza o salário do funcionário.

class Funcionario:
    def __init__(self, nome, salario, cargo):
        self.nome = nome
        self.salario = salario
        self.cargo = cargo

    def aumentar_salario(self, percentual_aumento):
        if percentual_aumento >= 0:
            aumento = (percentual_aumento / 100) * self.salario
            self.salario += aumento
            return f"Salário de {self.nome} atualizado para R${self.salario}"
        else:
            return "O percentual de aumento deve ser não negativo."

# Exemplo de uso:
funcionario1 = Funcionario("Alice", 3000.0, "Analista")
print(f"Salário inicial de {funcionario1.nome}: R${funcionario1.salario}")

funcionario1.aumentar_salario(10)
print(f"Novo salário de {funcionario1.nome}: R${funcionario1.salario}")

funcionario2 = Funcionario("Bob", 4000.0, "Gerente")
print(f"Salário inicial de {funcionario2.nome}: R${funcionario2.salario}")

funcionario2.aumentar_salario(5)
print(f"Novo salário de {funcionario2.nome}: R${funcionario2.salario}")
