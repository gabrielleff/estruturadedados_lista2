# Crie uma classe chamada “ContaBancaria” que tenha atributos “saldo” e “titular”. Implemente métodos “depositar” e “sacar” para manipular o saldo.

class ContaBancaria:
    def __init__(self, titular, saldo=0.0):
        self.titular = titular
        self.saldo = saldo

    def depositar(self, valor):
        if valor > 0:
            self.saldo += valor
            return f"Depósito de R${valor} realizado com sucesso. Novo saldo: R${self.saldo}"
        else:
            return "O valor do depósito deve ser maior que zero."

    def sacar(self, valor):
        if valor > 0 and valor <= self.saldo:
            self.saldo -= valor
            return f"Saque de R${valor} realizado com sucesso. Novo saldo: R${self.saldo}"
        elif valor <= 0:
            return "O valor do saque deve ser maior que zero."
        else:
            return "Saldo insuficiente para o saque."

# Exemplo de uso:
conta = ContaBancaria("João")
print(f"Saldo inicial da conta de {conta.titular}: R${conta.saldo}")

print(conta.depositar(100.0))
print(conta.sacar(50.0))
print(conta.sacar(70.0))
