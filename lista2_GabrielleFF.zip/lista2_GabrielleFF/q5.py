# Crie uma classe chamada “Pessoa” com atributos “nome” e “idade”. Implemente um método chamado “falar” que imprime uma mensagem com o nome da pessoa.

class Pessoa:
    def __init__(self, nome, idade):
        self.nome = nome
        self.idade = idade

    def falar(self):
        print(f"{self.nome} está falando.")

# Exemplo de uso:
pessoa1 = Pessoa("Alice", 30)
pessoa1.falar()  # Isso imprimirá "Alice está falando."

pessoa2 = Pessoa("Bob", 25)
pessoa2.falar()  # Isso imprimirá "Bob está falando."
